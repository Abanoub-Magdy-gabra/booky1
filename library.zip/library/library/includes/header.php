<div class="container">
  
  

    <?php if (isset($_SESSION['login'])) { ?>
        <div class="right-div">
            <a href="admin/logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
        </div>
        <section class="menu-section">
            <ul id="menu-top" class="navbar">
                <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                <li>
                    <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Account <i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="my-profile.php">My Profile</a></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="change-password.php">Change Password</a></li>
                    </ul>
                </li>
                <li><a href="issued-books.php">Issued Books</a></li>
            </ul>
        </section>
    <?php } else { ?>
        <section class="menu-section">
            <ul id="menu-top" class="navbar">
                <li><a href="index.php">      <img class="logo-image" src="logo.png" alt="Library Logo"/></a></li>
                <li><a href="index.php">Admin Login</a></li>
                <li><a href="signup.php">User Signup</a></li>
                <li><a href="login.php">User Login</a></li>
            </ul>
        </section>
    <?php } ?>
</div>
