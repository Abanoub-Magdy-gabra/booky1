<?php
include('includes/config.php');

$bookid=$_GET['id1'];
$rollno=$_GET['id2'];

$sql="select Category from tblstudents where StudentId='$rollno'";
$result=$dbh->query($sql);
$results=$result->fetchAll(PDO::FETCH_OBJ);

$category=$results;



if($category == 'GEN' || $category == 'OBC' )
{$sql1="update record set Date_of_Issue=curdate(),Due_Date=date_add(curdate(),interval 60 day),Renewals_left=1 where id='$bookid' and StudentId='$rollno'";
 
if($dbh->query($sql1))
{$sql3="update tblbooks set Availability=Availability-1 where id='$bookid'";
 $result=$dbh->query($sql3);
 $sql5="insert into message (StudentId,Msg,Date,Time) values ('$rollno','Your request for issue of BookId: $bookid  has been accepted',curdate(),curtime())";
 $result=$dbh->query($sql5);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:0.01; url=issue_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:1; url=issue_requests.php", true, 303);

}
}
else
{$sql2="update record set Date_of_Issue=curdate(),Due_Date=date_add(curdate(),interval 180 day),Renewals_left=Renewals_left-1 where id='$bookid' and StudentId='$rollno'";

if($dbh->query($sql2))
{$sql4="update tblbooks set Availability=Availability-1 where id='$bookid'";
 $result=$dbh->query($sql4);
 $sql6="insert into message (StudentId,Msg,Date,Time) values ('$rollno','Your request for issue of id: $bookid has been accepted',curdate(),curtime())";
 $result=$dbh->query($sql6);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:1; url=issue_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:1; url=issue_requests.php", true, 303);

}
}



?>