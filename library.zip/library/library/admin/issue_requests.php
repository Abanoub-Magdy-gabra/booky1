<?php

session_start();

include('includes/config.php');
?>

<?php 
if(!isset($_SESSION['alogin']))
{ header('location:index.php');}
else {
 

    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Library Management System | Admin Dash Board</title>
    <!-- BOOTSTRAP CORE STYLE  -->

    <!-- FONT AWESOME STYLE  -->
    <link href="asset/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    
     <link href="asset/css/style1.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
  <link href="asset/css/bootstrap.css" rel="stylesheet" />
</head>
    <body>
 <?php include('includes/header.php');?>
       
                    <div class="span9">
                        <center>
                        <a href="issue_requests.php" class="btn btn-info">Issue Requests</a>
                        <a href="renew_requests.php" class="btn btn-info">Renew Request</a>
                        <a href="return_requests.php" class="btn btn-info">Return Requests</a>
                        </center>
                        <h1><i>Issue Requests</i></h1>
                        <table class="table" id = "tables">
                                  <thead>
                                    <tr>
                                      <th>Roll Number</th>
                                      <th>Book Id</th>
                                      <th>Book Name</th>
                                      <th>Availabilty</th>
                                      <th></th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                            $sql="select * from record,tblbooks where Date_of_Issue is NULL and record.id=tblbooks.id order by Time";
                           $query = $dbh -> prepare($sql);

$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$returnedbooks=$query->rowCount();
                          if($query -> rowCount() > 0)
{
foreach ($results as $result){
                            
                            
                                
                            ?>
                                    <tr>
                                      <td><?php echo strtoupper($result->StudentId) ?></td>
                                      <td><?php echo $result->id ?></td>
                                      <td><b><?php echo $result->BookName ?></b></td>
                                      <td><?php echo $result->Availability?></td>
                                      <td><center>
                                        <?php 
                                        if($result->Availability> 0)
                                        {echo "<a href=\"accept.php?id1=".$result->id ."&id2=".strtoupper($result->StudentId)."\" class=\"btn btn-success\">Accept</a>";}
                                         ?>
                                        <a href="reject.php?id1=<?php echo $result->id ?>&id2=<?php echo strtoupper($result->StudentId) ?>" class="btn btn-danger">Reject</a>
                                    </center></td>
                                    </tr>
                               <?php } }?>
                               </tbody>
                                </table>
                            </div>
                    <!--/.span3-->
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2023 Library Management System </b>All rights reserved.
            </div>
        </div>
        
        <!--/.wrapper-->

      
    </body>

</html>


<?php }
 ?>