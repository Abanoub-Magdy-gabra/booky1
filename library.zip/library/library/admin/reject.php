<?php
include('includes/config.php');

$bookid=$_GET['id1'];

$rollno=$_GET['id2'];

$sql="delete from record where StudentId='$rollno' and id='$bookid'";

if($dbh->query($sql))
{
	$sql1="insert into message (StudentId,Msg,Date,Time) values ('$rollno','Your request for issue of BookId: $bookid  has been rejected',curdate(),curtime())";
 $result=$dbh->query($sql1);
echo "<script type='text/javascript'>alert('Success')</script>";
header( "Refresh:0.01; url=issue_requests.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=issue_requests.php", true, 303);

}




?>