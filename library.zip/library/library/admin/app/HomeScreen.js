import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';






const HomeScreen = ({ navigation }) => {
  
  return (
    
    <View style={styles.container}>
      <Text style={styles.heading}>Child Tracker App</Text>
      <Text style={styles.subheading}>Welcome Parent!</Text>
      <Button
        style={styles.button}
        onPress={() => navigation.navigate('LoginPage')} title='login'/>

      <Button
        style={styles.button} title='FirstForm'
        onPress={() => navigation.navigate('FirstForm')}/>
       
      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  subheading: {
    fontSize: 22,
    marginBottom: 40,
  },
  button: {
    backgroundColor: '#0099ff',
    padding: 10,
    margin: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
