import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const QRCodes = ({ route }) => {
  const [qrCodes, setQRCodes] = useState([]);

  useEffect(() => {
    const fetchQRCodes = async () => {
      const response = await fetch('http://example.com/get_qr_codes.php');
      const data = await response.json();
      setQRCodes(data.qrCodes);
    };

    fetchQRCodes();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text>QR Code ID: {item.qrId}</Text>
      <Text>National ID: {item.nationalId}</Text>
      <Text>Relative Relation: {item.relativeRelation}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={qrCodes}
        renderItem={renderItem}
        keyExtractor={(item) => item.qrId}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  item: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
});

export default QRCodes;