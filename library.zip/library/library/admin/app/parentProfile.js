import React, { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ParentProfile = () => {
  const [account, setAccount] = useState({});

  useEffect(() => {
    async function fetchAccount() {
      try {
        const sessionToken = await AsyncStorage.getItem('sessionToken');
        const response = await fetch('http://localhost/backend/get_account.php', {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${sessionToken}`,
          },credentials: 'include',
     withCredentials: true,
          body: JSON.stringify({
          
           
            // JSON payload
          }),
        });
        if (!response.ok) {
          // Handle non-200 HTTP response statuses
          throw new Error(`HTTP error: ${response.status}`);
        }
        const data = await response.json();
        setAccount(data.account);
      } catch (error) {
        console.error(error);
      }
    }
    fetchAccount();
  }, []);

  return (
    <View>
      <Text>This is the Parent Profile Page</Text>
      {account && account.username && (
        <Text>Username: {account.username}</Text>
      )}
      {account && account.start_date && (
        <Text>Start Date: {account.start_date}</Text>
      )}
    </View>
  );
};

export default ParentProfile;