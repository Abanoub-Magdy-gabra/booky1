import React, { useState } from 'react';
import { View, TextInput,Button } from 'react-native';

export default function FirstForm({ navigation }) {
 
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [start_date, setStartDate] = useState('');
  const [subscriptin_type, setSubscriptinType] = useState('');

  const handleFormSubmit = () => {
    const formData1 = {
    
      username,
      email,
      password,
      start_date,
      subscriptin_type,
    };
    navigation.navigate('SecondForm', { formData1 });
  };

  return (
    <View>
  
      <TextInput placeholder="username" onChangeText={setUsername} />
      <TextInput placeholder="email" onChangeText={setEmail} />
      <TextInput placeholder="password" onChangeText={setPassword} />
      <TextInput placeholder="start_date" onChangeText={setStartDate} />
      <TextInput
        placeholder="Subscriptin Type"
        onChangeText={setSubscriptinType}
      />
      <Button title="Next" onPress={handleFormSubmit} />
    </View>
  );
}
