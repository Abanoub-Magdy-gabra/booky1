import React, { useState } from 'react';
import { View, TextInput,Button } from 'react-native';
import axios from 'axios';

export default function SecondForm({ route }) {
  const { formData1 } = route.params;
  const [national_id, setNationalId] = useState('');
  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [birth_date, setBirthDate] = useState('');
  const [state, setState] = useState('');
  const [street, setStreet] = useState('');
  const [zip_code, setZipCode] = useState('');
  const [gender, setGender] = useState('');
  const [city, setCity] = useState('');

  const handleFormSubmit = () => {
    const formData2 = {
      national_id,
      fname,
      lname,
      birth_date,
      state,
      street,
      zip_code,
      city,
      gender,
      ...formData1,
    };
    axios
      .post('http://localhost/backend/signup.php', formData2)
      .then((response) => {
        console.log(response.data); // replace this with your own code
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <View>
      <TextInput placeholder="National ID" onChangeText={setNationalId} />
      <TextInput placeholder="First Name" onChangeText={setFname} />
      <TextInput placeholder="Last Name" onChangeText={setLname} />
      <TextInput placeholder="Birth Date" onChangeText={setBirthDate} />
      <TextInput placeholder="State" onChangeText={setState} />
      <TextInput placeholder="Street" onChangeText={setStreet} />
      <TextInput placeholder="Zip Code" onChangeText={setZipCode} />
      <TextInput placeholder="city" onChangeText={setCity} />
      <TextInput placeholder="Gender" onChangeText={setGender} />
      <Button title="Submit" onPress={handleFormSubmit} />
    </View>
  );
}
