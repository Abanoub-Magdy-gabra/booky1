import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';



import { v4 as uuidv4 } from 'uuid';

const ChildForm = () => {
  const [nationalId, setNationalId] = useState('');
  const [relativeRelation, setRelativeRelation] = useState('');
  const [qrCodeImage, setQRCodeImage] = useState('');
  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [birth_date, setBirthDate] = useState('');
  const [state, setState] = useState('');
  const [street, setStreet] = useState('');
  const [zip_code, setZipCode] = useState('');
  const [gender, setGender] = useState('');
  const [city, setCity] = useState('');
   const [url, setUrl] = useState('');


  const handleQRCode = (value) => {
    setQRCodeImage(value);
    setUrl('https://example.com');
  };

  const generateQRCodeValue = () => {
    const uuid = uuidv4();
    const randomNumber = Math.floor(Math.random() * 10000);
    const qrCodeImage = `${url}/${uuid}-${randomNumber}`;
    return qrCodeImage;
  };

  const handleFormUpdate = () => {
    const qrCodeValue = generateQRCodeValue();
    handleQRCode(qrCodeValue);

  };

  const databasehandeling = async () => {
    const formDataChild = {
      nationalId,
      relativeRelation,
      fname,
      lname,
      birth_date,
      state,
      street,
      zip_code,
      city,
      gender,
      qrCodeImage: qrCodeImage,
    };

    const response = await fetch('http://localhost/backend/save_qr_code.php', {
      method: 'POST',
      body: JSON.stringify(formDataChild),
      headers: {
        'Content-Type': 'application/json',
      },
    });

   
     
    const data = await response.json();
  

  };
  

  const handleSubmit = async () => {
    databasehandeling();
  };

  return (
    <View style={styles.container}>


      <TextInput
        placeholder="National ID"
        value={nationalId}
        onChangeText={(value) => { setNationalId(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Relative Relation"
        value={relativeRelation}
        onChangeText={(value) => { setRelativeRelation(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="First Name"
        value={fname}
        onChangeText={(value) => { setFname(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Last Name"
        value={lname}
        onChangeText={(value) => { setLname(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Birth Date"
        value={birth_date}
        onChangeText={(value) => { setBirthDate(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="State"
        value={state}
        onChangeText={(value) => { setState(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Street"
        value={street}
        onChangeText={(value) => { setStreet(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Zip Code"
        value={zip_code}
        onChangeText={(value) => { setZipCode(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="city"
        value={city}
        onChangeText={(value) => { setCity(value); handleFormUpdate(); }}
      />
      <TextInput
        placeholder="Gender"
        value={gender}
        onChangeText={(value) => { setGender(value); handleFormUpdate(); }}
      />
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },Buton:{width:30}
});

export default ChildForm;