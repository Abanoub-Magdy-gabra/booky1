<?php
// Check if the user is logged in
session_start();
/*if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}*/

// Connect to the database and retrievethe student's information
include('includes/config.php');
$stmt = $dbh->prepare('SELECT * FROM tblstudents WHERE StudentId = :id');
$stmt->bindValue(':id', /*$_SESSION['user_id']*/ 'SID02', PDO::PARAM_INT);
$stmt->execute();
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the student was found
if (!$student) {
    die('Student not found');
}

// Query the database for the student's borrowing history, reservation history, and liked books
$stmt = $dbh->prepare('SELECT * FROM tblbooks WHERE id IN (SELECT id FROM record WHERE StudentId = :id)');
$stmt->bindValue(':id', 'SID02', PDO::PARAM_INT);
$stmt->execute();
$borrowed_books = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $dbh->prepare('SELECT * FROM tblbooks WHERE id IN (SELECT id FROM record WHERE StudentId = :id)');
$stmt->bindValue(':id','SID02', PDO::PARAM_INT);
$stmt->execute();
$reserved_books = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<html>
    <head> <link href="asset/css/styleu.css" rel="stylesheet"/>
</head>
<body><html>
    <head>
        <link href="asset/css/style.css" rel="stylesheet">
    </head>
    <body>
        <!-- Display the student's information -->
        <header class="header">
             <img src="asset/img/user2.png" alt="User Icon" class="header__icon">
            <h1 class="header__title"><?php echo $student['FullName']; ?></h1>
        </header>
        <section class="profile">
            <h2 class="profile__title">Profile Information</h2>
            <ul class="profile__list">
                <li class="profile__item"><span class="profile__label">Email:</span> <?php echo $student['EmailId']; ?></li>
                <li class="profile__item"><span class="profile__label">Mobile Number:</span> <?php echo $student['MobileNumber']; ?></li>
            </ul>
        </section>

        <!-- Display the student's personalized bookshelf -->
        <section class="bookshelf">
            <h2 class="bookshelf__title">My Bookshelf</h2>
            <h3 class="bookshelf__subtitle">Borrowed Books</h3>
            <?php if ($borrowed_books): ?>
                <ul class="bookshelf__list">
                    <?php foreach ($borrowed_books as $book): ?>
                        <li class="bookshelf__item"><?php echo $book['BookName']; ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="bookshelf__empty">You have not borrowed any books yet.</p>
            <?php endif; ?>

           
        </section>

      
        <!-- Display the student's reading history -->
      
    </body>
</html>