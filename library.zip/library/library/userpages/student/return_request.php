<?php
session_start();
include('../includes/config.php');

if ($_SESSION['login']) {
    $email=$_SESSION['login'];
    if (isset($_GET['id'])) {
        $bookid = $_GET['id'];
        
        $query = "UPDATE record SET Date_of_Return = NOW() WHERE id = :bookid AND StudentId = (SELECT StudentId FROM tblstudents WHERE EmailId = :email) AND Date_of_Return IS NULL";
        $stmt = $dbh->prepare($query);
        $stmt->bindParam(':bookid', $bookid);
        $stmt->bindParam(':email', $_SESSION['login']);
        $result = $stmt->execute();

// Prepare the SQL statement
$stmt1 = $dbh->prepare("INSERT INTO `return`(`StudentId`, `id`) VALUES (:studentid, :bookid)");

// Bind the parameters
$stmt1->bindParam(':studentid', $studentid);
$stmt1->bindParam(':bookid', $bookid);

// Set the parameter values

// Execute the statement
$result = $stmt->execute();

if ($result) {
    echo "Data inserted successfully";
} else {
    echo "Error inserting data";
}


        if ($result) {
            
            echo "<script type='text/javascript'>window.location.href = 'current.php';</script>";
        } else {
            echo "<script type='text/javascript'>alert('Error while returning the book. Please try again.')</script>";
            echo "<script type='text/javascript'>window.location.href = 'current.php';</script>";
        }
   
    $stmt3 = $dbh->prepare("SELECT StudentId FROM tblstudents WHERE EmailId = :email");
$email=$_SESSION['login'];
// Bind the parameter
$stmt3->bindParam(':email', $email);

// Set the parameter value using a variable


// Execute the statement
$stmt3->execute();

// Fetch the result as an associative array
$result = $stmt3->fetch(PDO::FETCH_ASSOC);

// Store the value of the StudentId column in a variable
$studentId = $result['StudentId'];
    $stmt1 = $dbh->prepare("INSERT INTO `return`(`StudentId`, `id`) VALUES (:studentid, :bookid)");
$stmt1->bindParam(':studentid', $studentId); 
$stmt1->bindParam(':bookid', $bookid); 
$stmt1->execute();
 } else {
        echo "<script type='text/javascript'>alert('Invalid request. Please try again.')</script>";
        echo "<script type='text/javascript'>window.location.href = 'current.php';</script>";
    }
} else {
    echo "<script type='text/javascript'>alert('AccessDenied!!!')</script>";
}

?>
