<?php
// Start the session
session_start();

// Include the database configuration file
include('includes/config.php');

// Check if the user is logged in
if (!isset($_SESSION['login'])) {
    header('Location: login.php');
    exit();
}

// Get the email of the logged-in user
$email = $_SESSION['login'];

// Check if the user is logged in


// Check if the borrow book form has been submitted
if (isset($_POST['BorrowBook'])) {
    // Get the book ID from the form submission
    $bookId = $_POST['id'];
$email = $_SESSION['login'];
    // Check if the book is available for borrowing
    $stmt1 = $dbh->prepare("SELECT * FROM tblbooks WHERE id = :bookId AND Availability > 0 ");
    $stmt1->bindValue(':bookId', $bookId, PDO::PARAM_INT);
    $stmt1->execute();
    $book = $stmt1->fetch(PDO::FETCH_ASSOC);
var_dump($book);
var_dump($email);
    if ($book) {
        // Update the book availability status to "Borrowed"
        $stmt2 = $dbh->prepare("UPDATE tblbooks SET Availability = Availability - 1 WHERE id = :bookId");
        $stmt2->bindValue(':bookId', $bookId, PDO::PARAM_INT);
        $stmt2->execute();

// Prepare the SQL statement
       $stmt2 = $dbh->prepare("SELECT StudentId FROM tblstudents WHERE EmailId = :email");

// Bind the email parameter
      $stmt2->bindValue(':email', $email, PDO::PARAM_STR);

// Execute the query 
    $stmt2->execute();

// Fetch the result



        // Insert a new record into the record table
        $studentId1 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $studentId = $studentId1['StudentId'];

        var_dump($studentId);
        // Replace with the ID of the logged-in student
       
        $stmt3 = $dbh->prepare("INSERT INTO record (id, StudentId) VALUES (:bookId, :studentId)");
        $stmt3->bindValue(':bookId', $bookId, PDO::PARAM_INT);
        $stmt3->bindValue(':studentId', $studentId, PDO::PARAM_STR);
      
        $stmt3->execute();
       
// Prepare the SQL query
$sql = "INSERT INTO renew (StudentId, id) VALUES (:studentId, :id)";

// Prepare the statement
$stmt = $dbh->prepare($sql);

// Bind the parameters
$stmt->bindParam(':studentId', $studentId);
$stmt->bindParam(':id', $bookId);

// Execute the query
if ($stmt->execute()) {
    echo "Data inserted successfully.";
} else {
    echo "Error inserting data: " . $stmt->errorInfo()[2];
}
        // Redirect the user to the borrowed books page
        header('Location: borrowed_books.php');
        exit();
    } else {
        // The book is not available for borrowing
        echo "Sorry, this book is not currently available for borrowing.";
    }
} else { 
    // The borrow book form was not submitted
    header('Location: index.php');
    exit();
}
?>