<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        h1 {
            text-align: center;
            margin-top: 50px;
        }
        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            margin-bottom: 20px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>
    <h1>Payment Page</h1>
    <form method="POST" action="">
        <label for="payment_method">Payment Method:</label>
        <select name="payment_method" id="payment_method">
            <option value="credit_card">Credit Card</option>
            <option value="debit_card">Debit Card</option>
            <option value="payment_on_delivery">Payment on Delivery</option>
        </select>

        <div id="credit_card_details">
            <label for="card_number">Card Number:</label>
            <input type="text" name="card_number" id="card_number">
    
            <label for="expiry_month">Expiry Month:</label>
            <input type="text" name="expiry_month" id="expiry_month">
    
            <label for="expiry_year">Expiry Year:</label>
            <input type="text" name="expiry_year" id="expiry_year">
    
            <label for="cvv">CVV:</label>
            <input type="text" name="cvv" id="cvv">
        </div>

        <input type="submit" value="Pay">
    </form>

    <script>
        // Hide credit_card_details by default
        document.getElementById('credit_card_details').style.display = 'none';

        // Show credit_card_details if credit_card or debit_card is selected
        document.getElementById('payment_method').addEventListener('change', function() {
            var paymentMethod = document.getElementById('payment_method').value;
            if (paymentMethod === 'credit_card' || paymentMethod === 'debit_card') {
                document.getElementById('credit_card_details').style.display = 'block';
            } else {
                document.getElementById('credit_card_details').style.display = 'none';
            }
        });
    </script>
</body>
</html>