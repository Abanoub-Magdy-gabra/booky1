<?php
    // Start the session
    session_start();
    
    // Include the database configuration file
    include('includes/config.php');
    
    // Define variables for pagination and sorting
    $limit = 10; // Number of books to display per page
    $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
    $start = ($page - 1) * $limit; // Starting index for books to display
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'BookName'; // Sorting criteria
    $order = isset($_GET['order']) ? $_GET['order'] : 'asc'; // Sorting order
    
    // Define variables for search functionality
    $search = isset($_GET['search']) ? $_GET['search'] : ''; // Search keyword
    
    // Get the total number of books from the database (for pagination)
    $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM tblbooks WHERE BookName LIKE :search");
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_books = $row['count'];
    
    // Calculate the total number of pages (for pagination)
    $total_pages = ceil($total_books / $limit);
    
    // Get the list of books from the database
    $stmt = $dbh->prepare("SELECT tblbooks.*, tblauthors.AuthorName FROM tblbooks JOIN tblauthors ON tblbooks.AuthorId = tblauthors.id WHERE tblbooks.BookName LIKE :search ORDER BY $sort $order LIMIT :start, :limit");
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    $stmt->bindValue(':start', $start, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Close the database connection
    unset($dbh);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Library Home Page</title>
    
   <link href="asset/css/styls.css" rel="stylesheet"/>
</head>
<body>

    
    <section class="book-list">
        <div class="container">
           
               <?php include ('includes/header.php') ?>
<div class="welcome">
  <h2>Welcome to  BOOKY!</h2>
  <p>Thank you for choosing our library for your reading needs. Our collection is constantly growing, so be sure to check back often for new books!</p>
</div>
            <form action="" method="get" class="search-form">
                <input type="text" name="search" placeholder="Search books" value="<?php echo $search; ?>">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
            

       
            <div class="sort-form">
                <label for="sort">Sort by:</label>
                <select name="sort" id="sort">
                    <option value="BookName" <?php if ($sort == 'BookName') echo 'selected'; ?>>Title</option>
                    <option value="AuthorName" <?php if ($sort == 'AuthorName') echo 'selected'; ?>>Author</option>
                    <option value="BookPrice" <?php if ($sort == 'BookPrice') echo 'selected'; ?>>Year</option>
                </select>
                
                <label for="order">Order:</label>
                <select name="order" id="order">
                    <option value="asc" <?php if ($order == 'asc') echo 'selected'; ?>>Ascending</option>
                    <option value="desc" <?php if ($order == 'desc') echo 'selected'; ?>>Descending</option>
                </select>
                
                <button type="button" onclick="sortBooks()">Sort</button>
            </div>
 
     <?php if (count($books) > 0): ?>
                <ul class="book-grid">
                   <?php foreach ($books as $book): ?>
    <li>
        <img src="asset/img/<?php echo $book['bookimage']; ?>" alt="<?php echo $book['BookName']; ?>">
       <h2><?php echo $book['BookName']; ?></h2>
        <p>Author: <?php echo $book['AuthorName']; ?></p>
        <p>Price: <?php echo $book['BookPrice']; ?></p>
        <form method="post" action="borrow_book.php">
            <input type="hidden" name="id" value="<?php echo $book['id']; ?>">
            <button type="submit" name="BorrowBook">Borrow</button>
        </form>
    </li>
<?php endforeach; ?>
                </ul>
                
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort; ?>&order=<?php echo $order; ?>&search=<?php echo $search; ?>"><i class="fa fa-arrow-left"></i> Prev</a>
                    <?php endif; ?>
                    
                   <?php for ($i = 1; $i <= $total_pages; $i++): ?>
    <?php if ($i == $page): ?>
        <span class="current-page"><?php echo $i; ?></span>
    <?php else: ?>
        <a href="?page=<?php echo $i; ?>&sort=<?php echo $sort; ?>&order=<?php echo$order; ?>&search=<?php echo $search; ?>"><?php echo $i; ?></a>
    <?php endif; ?>
<?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort; ?>&order=<?php echo $order; ?>&search=<?php echo $search; ?>">Next <i class="fa fa-arrow-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>No books found.</p>
            <?php endif; ?>
        </div>
    </section>
    
    <?php include('includes/footer.php'); ?>
    
    <script>
        // Function to sort books by the selected criteria and order
        function sortBooks() {
            var sort = document.getElementById("sort").value;
            var order = document.getElementById("order").value;
            var search = "<?php echo $search; ?>";
            window.location.href = "?sort=" + sort + "&order=" + order + "&search=" + search;
        }
    </script>
</body>
</html>