<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    
   <link href="asset/css/styls.css" rel="stylesheet"/>
    <style>
        /* Add your custom styles here */
        
       

        .btn-primary {
            background-color: #337ab7;
            border-color: #337ab7;
        }

        .btn-primary:hover {
            background-color: #286090;
            border-color: #286090;
        }

        .success-message {
            color: #28a745;
            font-weight: bold;
        }

        .error-message {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>
<body>
       
    <div class="container">
        <section> 
            <ul id="menu-top"> <img src="../logo.png" class="logo-image"/>
      <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
      
        <li ><a  href="student/profile.php">My Profile</a></li>
        
            <li><a href="contact-us.php">Contact Us</a></li> 
        <div class="right-div"> <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a> </div>
     </ul> </section>
        <h2 class="text-">Contact Us</h2>
        <form id="contactForm" method="post" action="process.php">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="message">Message:</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <div id="formMessages" class="mt-4"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // Handle form submission
            $('#contactForm').on('submit', function(e) {
                e.preventDefault();
                var form = $(this);
                var formMessages = $('#formMessages');

                $.ajax({
                    type: 'POST',
                    url: form.attr('action'),
                    data: form.serialize(),
                    success: function(response) {
                        formMessages.html('<p class="success-message">Thank you! Your message has been sent.</p>');
                        form.trigger('reset');
                    },
                    error: function(xhr, status, error) {
                        formMessages.html('<p class="error-message">Oops! Something went wrong. Please try again later.</p>');
                    }
                });
            });
        });
    </script>
</body>
</html>
