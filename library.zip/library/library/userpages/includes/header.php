<div class="container">
  
  

    <?php if (isset($_SESSION['login'])) { ?>
        
     <section class="menu-section"> <ul id="menu-top" class="navbar"> <img src="../logo.png" class="logo-image"/>
      <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
      
        <li ><a  href="student/profile.php">My Profile</a></li>
        
            <li><a href="contact-us.php">Contact Us</a></li> 
        <div class="right-div"> <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a> </div>
     </ul> 
    <?php } else { ?>
        <section class="menu-section">
            <ul id="menu-top" class="navbar">
                <li><a href="index.php">      <img class="logo-image" src="../../library/logo.png" alt="Library Logo"/></a></li>
                <li><a href="index.php">Admin Login</a></li>
                <li><a href="signup.php">User Signup</a></li>
                <li><a href="login.php">User Login</a></li>
            </ul>
        </section>
    <?php } ?>
</div>
