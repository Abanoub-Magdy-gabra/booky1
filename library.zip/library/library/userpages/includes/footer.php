<section class="footer-section">
  <div class="container">
    <div class="row">
      
      <div class="col-md-6">
        <h3>Contact Us</h3>
        <p>123 Main Street<br>Anytown, USA 12345</p>
        <p>Email: info@example.com<br>Phone: 555-555-5555</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <hr>
        <p>&copy; 2023 My Website. All Rights Reserved.</p>
      </div>
    </div>
  </div>
</section>