<?php
// Start the session
session_start();

// Include the database configuration file
include('includes/config.php');

// Define variables and initialize with empty values
 $StudentId=$EmailId = $password = $confirm_password = "";
 $StudentId= $EmailId_err = $password_err = $confirm_password_err = "";

// Process submitted form data
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate username
    if(empty(trim($_POST["EmailId"]))){
        $EmailId_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM tblstudents WHERE EmailId = :EmailId";
        
        if($stmt = $dbh->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":EmailId", $param_EmailId, PDO::PARAM_STR);
            
            // Set parameters
            $param_EmailId = trim($_POST["EmailId"]);
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $EmailId_err = "This EmailId is already taken.";
                } else{
                    $EmailId = trim($_POST["EmailId"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
    
    
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($EmailId_err) && empty($password_err) && empty($confirm_password_err)){
        

    // Retrieve the current maximum student ID from the database
    $query = "SELECT MAX(StudentId) as max_id FROM tblstudents";
    $result = $dbh->query($query);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $max_id = $row['max_id'];

    // Parse the number from the maximum student ID and increment it by 1
    $number = substr($max_id, 3);
    $number++;

    // Generate the new student ID by concatenating the prefix "SID" with the incremented number, padded with leading zeros if necessary
    $StudentId = 'SID' . str_pad($number, 3, '0', STR_PAD_LEFT);

        // Prepare an insert statement
        $sql = "INSERT INTO tblstudents ( EmailId, password,StudentId) VALUES ( :EmailId, :password,:StudentId)";
         
        if($stmt = $dbh->prepare($sql)){
            // Bind variables to the prepared statement as parameters
           
            $stmt->bindParam(":EmailId", $param_EmailId, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            $stmt->bindParam(":StudentId", $param_StudentId, PDO::PARAM_STR);
            
          
            $param_EmailId = $EmailId;
            // Creates a password hash using a strong one-way hashing algorithm
            $param_password = $password; 
            $param_StudentId = $StudentId; 
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }
}
    // Close connection
    unset($dbh);

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
 <meta name="description" content="" />
 <meta name="author" content="" />
 <title>Online Library Management System</title>
 <!-- BOOTSTRAP CORE STYLE -->
 <link href="asset/css/bootstrap.css" rel="stylesheet" />
 <!-- FONT AWESOME STYLE -->
 <link href="asset/css/font-awesome.css" rel="stylesheet" />
 <!-- CUSTOM STYLE -->
 <link href="asset/css/style2.css" rel="stylesheet" />
 <!-- GOOGLE FONT -->
 <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
 <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
<div class="container">
<div class="row pad-botm">
<div class="col-md-12">
</div>
</div>
 
<!--SIGN UP PANEL START--> 
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
<div class="panel panel-info">
<div class="panel-heading">
 Sign up 
</div>
<div class="panel-body">
<form role="form" method="post">


<div class="form-group <?php echo (!empty($EmailId_err)) ? 'has-error' : ''; ?>">
<label>Enter Email</label>
<input class="form-control" type="email" name="EmailId" value="<?php echo $EmailId; ?>" required />
<span class="help-block"><?php echo $EmailId_err; ?></span>
</div>

<div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
<label>Password</label>
<input class="form-control" type="password" name="password" value="<?php echo $password; ?>" required />
<span class="help-block"><?php echo $password_err; ?></span>
</div>

<div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
<label>Confirm Password</label>
<input class="form-control" type="password" name="confirm_password" value="<?php echo $confirm_password; ?>" required />
<span class="help-block"><?php echo $confirm_password_err; ?></span>
</div>

<button type="submit" name="signup" class="btn btn-info">SIGN UP </button>

</form>
 </div>
</div>
</div>
</div> 
<!---SIGN UP PABNEL END--> 
 
 
 </div>
 </div>
 <!-- CONTENT-WRAPPER SECTION END-->
 <?php include('includes/footer.php');?>
 <!-- FOOTER SECTION END-->
 <script src="assets/js/jquery-1.10.2.js"></script>
 <!-- BOOTSTRAP SCRIPTS -->
 <script src="assets/js/bootstrap.js"></script>
 <!-- CUSTOM SCRIPTS -->
 <script src="assets/js/custom.js"></script>
</body>
</html>

